"""
gui/app.py  —  v3
-----------------
Top-level QMainWindow. New 4-column layout matching the design sketch.

Layout:
  ┌───────────┬──────────────────────┬──────────────────────┬──────────────┐
  │ IMU Status│   3D Skeleton        │  Session / Exercise  │  (merged)    │
  │ + Angles  │   (pyqtgraph GL)     │  Library / Progress  │              │
  │           ├──────────────────────┤  Recording / Quest.  │              │
  │           │  Clinical Metrics    │                      │              │
  │           │  Plot + ADL          │                      │              │
  └───────────┴──────────────────────┴──────────────────────┴──────────────┘
  [Haptic All] [Sync All] [Calibrate] [Start/End Session]           [Quit]

50 Hz QTimer drives all updates. BLE runs on its own background thread.
Haptic logic: rep complete, ROM limit reached, or large deviation.
"""

import time
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QPushButton, QLabel, QSplitter, QSizePolicy
)
from PyQt5.QtCore import QTimer, Qt

from ble.ble_state import AppState
from ble.ble_manager import BLEManager
from calc.calibration import Calibration
from calc.joint_angles import AngleProcessor
from calc.rep_detector import RepDetector
from calc.session_recorder import SessionRecorder
from gui.imu_panel import IMUPanel
from gui.render_widget import RenderWidget
from gui.metrics_panel import MetricsPanel
from gui.session_panel import SessionPanel

WIN_W, WIN_H = 1600, 950

BG = "#000000"; PANEL_BG = "#0a0a0a"; BORDER = "#232330"; TEXT = "#f0f0f0"; DIM = "#6e6e82"
C_GREEN = "#00ffa0"; C_RED = "#ff3c3c"; C_AMBER = "#ffc800"; C_ACCENT = "#00b4ff"; C_PURPLE = "#b450ff"

GLOBAL_STYLE = f"""
QMainWindow, QWidget {{ background: {BG}; color: {TEXT};
    font-family: 'Consolas','Courier New',monospace; font-size: 12px; }}
QFrame {{ background: {PANEL_BG}; border: 1px solid {BORDER}; border-radius: 4px; }}
QPushButton {{ background: #191926; color: {TEXT}; border: 1px solid {BORDER};
    border-radius: 4px; padding: 5px 12px; font-size: 11px; }}
QPushButton:hover  {{ background: #2a2a3a; }}
QPushButton:pressed {{ background: #0e0e18; }}
QLabel {{ background: transparent; border: none; }}
QListWidget {{ background: {PANEL_BG}; border: 1px solid {BORDER}; border-radius: 3px; }}
QSpinBox  {{ background: #191926; color: {TEXT}; border: 1px solid {BORDER}; padding: 2px; }}
"""

HAPTIC_ROM_FRACTION   = 0.90   # haptic when angle reaches 90% of measured ROM limit
HAPTIC_DEVIATION_DEG  = 25.0   # haptic if primary angle deviates from expected plane


class App(QMainWindow):
    def __init__(self, state: AppState, ble: BLEManager,
                 calibration: Calibration, angle_processor: AngleProcessor):
        super().__init__()
        self._state    = state
        self._ble      = ble
        self._cal      = calibration
        self._angles   = angle_processor
        self._recorder = SessionRecorder()
        self._repdet   = RepDetector()
        self._last_haptic_t = 0.0
        self._recording = False

        self.setWindowTitle("Frozen Shoulder Rehab  —  v3")
        self.setFixedSize(WIN_W, WIN_H)
        self.setStyleSheet(GLOBAL_STYLE)
        self._build_ui()
        self._start_timer()

    def _build_ui(self):
        root = QWidget(); self.setCentralWidget(root)
        root_lay = QVBoxLayout(root)
        root_lay.setContentsMargins(0,0,0,0); root_lay.setSpacing(0)
        root_lay.addWidget(self._make_title())

        # ── Four-column main area ─────────────────────────────────────────────
        main = QWidget()
        main_lay = QHBoxLayout(main)
        main_lay.setContentsMargins(4,4,4,0); main_lay.setSpacing(4)

        self._imu_panel  = IMUPanel(self._state, self._ble)
        self._imu_panel.setFixedWidth(200)

        # Centre column: 3D render (top) + metrics plot (bottom)
        centre = QWidget()
        centre_lay = QVBoxLayout(centre)
        centre_lay.setContentsMargins(0,0,0,0); centre_lay.setSpacing(4)
        self._render_widget = RenderWidget(self._state)
        self._metrics_panel = MetricsPanel(self._state, self._cal)
        self._render_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._metrics_panel.setFixedHeight(230)
        centre_lay.addWidget(self._render_widget, stretch=1)
        centre_lay.addWidget(self._metrics_panel)

        self._session_panel = SessionPanel(
            self._state, self._recorder, self._repdet
        )
        self._session_panel.setFixedWidth(250)

        # Connect session panel signals
        self._session_panel.exercise_changed.connect(self._on_exercise_changed)
        self._session_panel.session_started.connect(lambda: None)
        self._session_panel.session_ended.connect(lambda: None)
        self._session_panel.record_toggled.connect(self._on_record_toggled)

        main_lay.addWidget(self._imu_panel)
        main_lay.addWidget(centre, stretch=1)
        main_lay.addWidget(self._session_panel)
        root_lay.addWidget(main, stretch=1)
        root_lay.addWidget(self._make_bottom())

    def _make_title(self):
        bar = QWidget(); bar.setFixedHeight(30)
        bar.setStyleSheet(f"background: {PANEL_BG}; border-bottom: 1px solid {BORDER};")
        lay = QHBoxLayout(bar); lay.setContentsMargins(12,0,12,0)
        t = QLabel("FROZEN SHOULDER REHAB")
        t.setStyleSheet(f"color: {C_ACCENT}; font-weight: bold; font-size: 12px;")
        s = QLabel("  —  3× XIAO nRF52840  |  BNO085  |  DRV2605L  |  BLE")
        s.setStyleSheet(f"color: {DIM}; font-size: 10px;")
        lay.addWidget(t); lay.addWidget(s); lay.addStretch()
        return bar

    def _make_bottom(self):
        bar = QWidget(); bar.setFixedHeight(44)
        bar.setStyleSheet(f"background: {PANEL_BG}; border-top: 1px solid {BORDER};")
        lay = QHBoxLayout(bar); lay.setContentsMargins(12,4,12,4); lay.setSpacing(8)

        def _btn(label, colour, text_dark=False):
            b = QPushButton(label)
            tc = "#000" if text_dark else "#fff"
            b.setStyleSheet(
                f"QPushButton {{ background: {colour}; color: {tc}; font-weight: bold;"
                f" border: none; border-radius: 4px; padding: 5px 16px; }}"
                f"QPushButton:hover {{ opacity: 0.85; }}"
            )
            return b

        btn_haptic = _btn("Haptic All", C_AMBER, text_dark=True)
        btn_sync   = _btn("Sync All",   C_ACCENT, text_dark=True)
        btn_cal    = _btn("Calibrate",  C_GREEN,  text_dark=True)
        btn_quit   = _btn("Quit",       C_RED)

        btn_haptic.clicked.connect(self._ble.send_haptic_all)
        btn_sync.clicked.connect(self._ble.send_sync_all)
        btn_cal.clicked.connect(self._on_calibrate)
        btn_quit.clicked.connect(self.close)

        self._cal_status = QLabel("Not calibrated")
        self._cal_status.setStyleSheet(f"color: {C_AMBER}; font-size: 11px;")

        lay.addWidget(btn_haptic); lay.addWidget(btn_sync); lay.addWidget(btn_cal)
        lay.addWidget(self._cal_status)
        lay.addStretch()
        lay.addWidget(btn_quit)
        return bar

    def _start_timer(self):
        self._timer = QTimer(self)
        self._timer.setInterval(20)   # 50 Hz
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def _tick(self):
        now = time.monotonic()
        self._angles.update(now)

        with self._state.lock:
            calibrated = self._state.calibrated
            cap = self._cal.is_capturing()
            flex  = self._state.shoulder_flexion
            abd   = self._state.shoulder_abduction
            rot   = self._state.external_rotation
            elbow = self._state.elbow_flexion
            active = self._state.session_active
            rom_flex  = self._state.rom_flex_limit
            rom_abd   = self._state.rom_abd_limit

        # Update calibration status label
        if cap:
            self._cal_status.setText("Capturing 3s — hold I-pose...")
            self._cal_status.setStyleSheet(f"color: {C_ACCENT}; font-size: 11px;")
        elif calibrated:
            self._cal_status.setText("✓ Calibrated")
            self._cal_status.setStyleSheet(f"color: {C_GREEN}; font-size: 11px;")
        else:
            self._cal_status.setText("Not calibrated")
            self._cal_status.setStyleSheet(f"color: {C_AMBER}; font-size: 11px;")

        # Rep detection + haptic logic (only when session active)
        if active and calibrated:
            rep_done = self._repdet.update(flex, abd, rot, elbow, now)
            if rep_done:
                with self._state.lock:
                    self._state.session_reps = self._repdet.count
                self._trigger_haptic(now, "Rep complete")

            # ROM limit haptic
            if (abs(flex) >= HAPTIC_ROM_FRACTION * rom_flex or
                    abs(abd) >= HAPTIC_ROM_FRACTION * rom_abd):
                self._trigger_haptic(now, "ROM limit reached")

        # Record frame if recording
        if self._recording and active:
            self._recorder.record_frame(now, flex, abd, rot, elbow)

        self._imu_panel.refresh()
        self._render_widget.refresh()
        self._metrics_panel.refresh()
        self._session_panel.refresh()

    def _trigger_haptic(self, now: float, reason: str):
        if now - self._last_haptic_t < 1.0:   # debounce 1s
            return
        self._last_haptic_t = now
        self._ble.send_haptic_all()
        with self._state.lock:
            self._state.haptic_log.append((now, reason))
            if len(self._state.haptic_log) > 20:
                self._state.haptic_log.pop(0)
        print(f"[HAPTIC] {reason}")

    def _on_calibrate(self):
        ok = self._cal.capture()
        if not ok:
            print("[GUI] Calibration failed — connect all sensors first.")

    def _on_exercise_changed(self, name: str):
        with self._state.lock:
            self._state.current_exercise = name

    def _on_record_toggled(self, recording: bool):
        self._recording = recording

    def closeEvent(self, event):
        self._timer.stop()
        if self._recorder.is_active:
            self._recorder.end_session()
        self._ble.stop()
        event.accept()
