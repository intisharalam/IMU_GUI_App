"""
gui/session_panel.py  —  v3
---------------------------
Right column: session info, exercise library, rep counter, progress tracker,
exercise description + stick figure, ROM goal sphere control,
session questionnaire, recording controls.
"""

import time
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QFrame, QListWidget, QListWidgetItem,
    QSpinBox, QDialog, QDialogButtonBox, QFormLayout,
    QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal

PANEL_BG = "#0a0a0a"; BORDER = "#232330"; DIM = "#6e6e82"; TEXT = "#f0f0f0"
C_GREEN = "#00ffa0"; C_RED = "#ff3c3c"; C_AMBER = "#ffc800"
C_ACCENT = "#00b4ff"; C_PURPLE = "#b450ff"

EXERCISES = [
    "Shoulder Flexion Raise",
    "Shoulder Abduction",
    "External Rotation",
    "Pendulum Swing",
    "Elbow Curl",
]

EXERCISE_DESC = {
    "Shoulder Flexion Raise": "Raise arm forward.\nHold max 3s.\nTarget: flexion ROM.",
    "Shoulder Abduction":     "Raise arm sideways.\nHold max 3s.\nTarget: abduction ROM.",
    "External Rotation":      "Rotate arm outward.\nElbow at 90°.\nTarget: rotation ROM.",
    "Pendulum Swing":         "Lean forward.\nLet arm hang and swing gently.\nNo target angle.",
    "Elbow Curl":             "Bend elbow toward shoulder.\nHold max 3s.\nTarget: elbow ROM.",
}


def _section(title):
    lbl = QLabel(title)
    lbl.setStyleSheet(f"color: {DIM}; font-size: 9px; font-weight: bold; padding: 2px 0;")
    return lbl


def _frame():
    f = QFrame()
    f.setStyleSheet(
        f"QFrame {{ background: {PANEL_BG}; border: 1px solid {BORDER}; border-radius: 4px; }}"
    )
    return f


class QuestionnaireDialog(QDialog):
    def __init__(self, parent=None, title="Session Questionnaire"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedWidth(320)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self._pain = QSpinBox(); self._pain.setRange(0,10); self._pain.setValue(0)
        self._stiff = QSpinBox(); self._stiff.setRange(0,10); self._stiff.setValue(0)
        form.addRow("Pain (0–10):", self._pain)
        form.addRow("Stiffness (0–10):", self._stiff)
        lay.addLayout(form)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        lay.addWidget(btns)

    @property
    def pain(self): return self._pain.value()
    @property
    def stiffness(self): return self._stiff.value()


class SessionPanel(QWidget):
    """
    Signals:
        exercise_changed(str)   — emitted when user picks a new exercise
        session_started()       — emitted on Start Session
        session_ended()         — emitted on End Session
        record_toggled(bool)    — True=start recording, False=stop
    """
    exercise_changed = pyqtSignal(str)
    session_started  = pyqtSignal()
    session_ended    = pyqtSignal()
    record_toggled   = pyqtSignal(bool)

    def __init__(self, state, recorder, rep_detector, parent=None):
        super().__init__(parent)
        self._state     = state
        self._recorder  = recorder
        self._repdet    = rep_detector
        self._recording = False
        self._t_session = None
        self._pain_pre  = 0
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(4, 4, 4, 4)
        lay.setSpacing(6)

        # ── Session info ──────────────────────────────────────────────────────
        lay.addWidget(_section("SESSION"))
        sf = _frame()
        sl = QVBoxLayout(sf); sl.setContentsMargins(8,6,8,6); sl.setSpacing(3)
        self._sess_no  = QLabel("Session —"); self._sess_no.setStyleSheet(f"color:{C_ACCENT}; font-size:11px; font-weight:bold;")
        self._sess_time = QLabel("00:00"); self._sess_time.setStyleSheet(f"color:{TEXT}; font-size:18px; font-weight:bold;")
        self._reps_lbl  = QLabel("Reps: 0"); self._reps_lbl.setStyleSheet(f"color:{C_GREEN}; font-size:12px; font-weight:bold;")
        sl.addWidget(self._sess_no)
        sl.addWidget(self._sess_time)
        sl.addWidget(self._reps_lbl)
        lay.addWidget(sf)

        # ── Exercise library ──────────────────────────────────────────────────
        lay.addWidget(_section("EXERCISE"))
        ef = _frame()
        el = QVBoxLayout(ef); el.setContentsMargins(4,4,4,4); el.setSpacing(2)
        self._ex_list = QListWidget()
        self._ex_list.setStyleSheet(
            f"QListWidget {{ background: {PANEL_BG}; border: none; color: {DIM}; font-size: 10px; }}"
            f"QListWidget::item:selected {{ background: #00b4ff20; color: {C_ACCENT}; }}"
        )
        self._ex_list.setFixedHeight(110)
        for ex in EXERCISES:
            self._ex_list.addItem(QListWidgetItem(ex))
        self._ex_list.setCurrentRow(0)
        self._ex_list.currentTextChanged.connect(self._on_exercise_changed)
        el.addWidget(self._ex_list)
        lay.addWidget(ef)

        # ── Exercise description ──────────────────────────────────────────────
        df = _frame()
        dl = QVBoxLayout(df); dl.setContentsMargins(8,6,8,6)
        self._desc_lbl = QLabel(EXERCISE_DESC[EXERCISES[0]])
        self._desc_lbl.setStyleSheet(f"color:{DIM}; font-size:10px;")
        self._desc_lbl.setWordWrap(True)
        dl.addWidget(self._desc_lbl)
        lay.addWidget(df)

        # ── Progress vs last session ──────────────────────────────────────────
        lay.addWidget(_section("PROGRESS vs LAST SESSION"))
        pf = _frame()
        pl = QHBoxLayout(pf); pl.setContentsMargins(8,6,8,6); pl.setSpacing(8)
        self._prog_labels = {}
        for key, colour in [("Flex", C_ACCENT), ("Abd", C_GREEN),
                             ("ExtRot", C_AMBER), ("Elbow", C_PURPLE)]:
            box = QVBoxLayout()
            k = QLabel(key); k.setStyleSheet(f"color:{DIM}; font-size:9px;")
            v = QLabel("—"); v.setStyleSheet(f"color:{colour}; font-size:11px; font-weight:bold;")
            box.addWidget(k); box.addWidget(v)
            pl.addLayout(box)
            self._prog_labels[key] = v
        lay.addWidget(pf)

        # ── Recording ─────────────────────────────────────────────────────────
        lay.addWidget(_section("RECORDING"))
        rf = _frame()
        rl = QHBoxLayout(rf); rl.setContentsMargins(8,6,8,6); rl.setSpacing(6)
        self._rec_btn = QPushButton("⏺  Record")
        self._rec_btn.setFixedHeight(26)
        self._rec_btn.setStyleSheet(
            f"QPushButton {{ background: #b450ff20; color: {C_PURPLE}; border: 1px solid #b450ff40;"
            f" border-radius: 3px; font-size: 10px; }}"
            f"QPushButton:hover {{ background: #b450ff40; }}"
        )
        self._rec_btn.clicked.connect(self._toggle_record)
        rl.addWidget(self._rec_btn)
        lay.addWidget(rf)

        lay.addStretch()

        # ── Session control buttons ───────────────────────────────────────────
        btn_row = QHBoxLayout()
        self._start_btn = QPushButton("Start Session")
        self._end_btn   = QPushButton("End Session")
        self._start_btn.setFixedHeight(28)
        self._end_btn.setFixedHeight(28)
        self._start_btn.setStyleSheet(
            f"QPushButton {{ background: {C_GREEN}; color: #000; font-weight: bold;"
            f" border: none; border-radius: 4px; font-size: 11px; }}"
            f"QPushButton:hover {{ background: #00cc80; }}"
        )
        self._end_btn.setStyleSheet(
            f"QPushButton {{ background: {C_RED}; color: #fff; font-weight: bold;"
            f" border: none; border-radius: 4px; font-size: 11px; }}"
            f"QPushButton:hover {{ background: #cc3030; }}"
        )
        self._end_btn.setEnabled(False)
        self._start_btn.clicked.connect(self._on_start)
        self._end_btn.clicked.connect(self._on_end)
        btn_row.addWidget(self._start_btn)
        btn_row.addWidget(self._end_btn)
        lay.addLayout(btn_row)

        # Init progress
        self._update_progress()

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def _on_exercise_changed(self, name):
        self._desc_lbl.setText(EXERCISE_DESC.get(name, ""))
        self._repdet.set_exercise(name)
        self.exercise_changed.emit(name)

    def _on_start(self):
        dlg = QuestionnaireDialog(self, "Pre-Session Questionnaire")
        if dlg.exec_() == QDialog.Accepted:
            self._pain_pre = dlg.pain
        else:
            self._pain_pre = 0
        exercise = self._ex_list.currentItem().text() if self._ex_list.currentItem() else ""
        self._recorder.start_session(exercise=exercise, pain_pre=self._pain_pre)
        self._repdet.reset()
        self._repdet.set_exercise(exercise)
        self._t_session = time.monotonic()
        self._start_btn.setEnabled(False)
        self._end_btn.setEnabled(True)
        with self._state.lock:
            self._state.session_active   = True
            self._state.session_reps     = 0
            self._state.current_exercise = exercise
        self.session_started.emit()
        print(f"[SESSION] Started: {exercise}, pain_pre={self._pain_pre}")

    def _on_end(self):
        dlg = QuestionnaireDialog(self, "Post-Session Questionnaire")
        pain_post = 0
        if dlg.exec_() == QDialog.Accepted:
            pain_post = dlg.pain
        self._recorder.end_session(pain_post=pain_post)
        self._start_btn.setEnabled(True)
        self._end_btn.setEnabled(False)
        with self._state.lock:
            self._state.session_active = False
        self._update_progress()
        self.session_ended.emit()

    def _toggle_record(self):
        self._recording = not self._recording
        if self._recording:
            self._rec_btn.setText("⏹  Stop")
            self._rec_btn.setStyleSheet(
                f"QPushButton {{ background: #ff3c3c20; color: {C_RED}; border: 1px solid #ff3c3c40;"
                f" border-radius: 3px; font-size: 10px; }}"
            )
        else:
            self._rec_btn.setText("⏺  Record")
            self._rec_btn.setStyleSheet(
                f"QPushButton {{ background: #b450ff20; color: {C_PURPLE}; border: 1px solid #b450ff40;"
                f" border-radius: 3px; font-size: 10px; }}"
            )
        self.record_toggled.emit(self._recording)

    def _update_progress(self):
        last = self._recorder.get_last_session_maxima()
        if not last:
            for v in self._prog_labels.values():
                v.setText("—")
            return
        with self._state.lock:
            mf = self._state.max_flexion; ma = self._state.max_abduction
            mr = self._state.max_ext_rot; me = self._state.max_elbow
        def _delta(cur, prev):
            d = cur - prev
            return f"{d:+.0f}°" if prev else "—"
        self._prog_labels["Flex"].setText(_delta(mf, last.get("max_flex",0)))
        self._prog_labels["Abd"].setText(_delta(ma, last.get("max_abd",0)))
        self._prog_labels["ExtRot"].setText(_delta(mr, last.get("max_ext_rot",0)))
        self._prog_labels["Elbow"].setText(_delta(me, last.get("max_elbow",0)))

    # ── Per-frame refresh ─────────────────────────────────────────────────────

    def refresh(self):
        if self._t_session is not None:
            elapsed = int(time.monotonic() - self._t_session)
            m, s = divmod(elapsed, 60)
            self._sess_time.setText(f"{m:02d}:{s:02d}")
        with self._state.lock:
            reps = self._state.session_reps
        self._reps_lbl.setText(f"Reps: {reps}")
