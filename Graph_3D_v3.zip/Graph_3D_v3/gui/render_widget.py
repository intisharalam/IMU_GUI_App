"""
gui/render_widget.py  —  v3
---------------------------
Centre-top panel: PyQtGraph OpenGL arm skeleton.

New in v3:
  - Goal sphere (red dashed) at the target ROM angle for the active exercise.
  - ROM measurement mode: call start_rom_measure() to begin; the sphere
    is placed at the live max angle reached and held there; end_rom_measure()
    returns the ROM values found.
  - Uses corrected v3 joint_angles pipeline (swing-twist, filtered).
  - Euler jump gate: if the computed segment direction changes by an
    implausible amount in one frame, the previous geometry is kept.

Pipeline per frame (matches joint_angles.py exactly):
  1. Read raw quats from AppState.
  2. Filter + mount → anatomical frame.
  3. Remove I-pose offset (ref.inv() * live).
  4. Relative rotations: shoulder = chest.inv() * arm
                         elbow    = arm.inv()   * wrist
  5. Rotate DOWN → segment directions.
  6. Apply WORLD_ROT (+90° Y) → display frame.
"""

import numpy as np
from scipy.spatial.transform import Rotation

import pyqtgraph.opengl as gl
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
)
from PyQt5.QtGui import QVector3D

from calc.joint_angles import MOUNT, to_anatomical, swing_twist, QuaternionFilter

UPPER_ARM_LEN = 0.30
FOREARM_LEN   = 0.25

C_TORSO     = (1.0, 1.0, 1.0, 0.10)
C_UPPER_ARM = (0.27, 0.71, 1.00, 1.0)
C_FOREARM   = (0.70, 0.31, 1.00, 1.0)
C_SHOULDER  = (1.00, 0.78, 0.00, 1.0)
C_ELBOW     = (0.00, 1.00, 0.63, 1.0)
C_WRIST     = (1.00, 0.24, 0.24, 1.0)
C_GOAL      = (1.00, 0.24, 0.24, 0.35)
BG_COLOR    = (0.04, 0.04, 0.04, 1.0)

DOWN_NP    = np.array([0., -1., 0.])
IDENTITY_Q = (1., 0., 0., 0.)
WORLD_ROT  = Rotation.from_euler("Y", 90, degrees=True)

DIR_JUMP_THRESH = 0.35   # max dot-product deviation per frame (~20°)


def _sphere_mesh(radius, rows=10, cols=10):
    verts, faces = [], []
    for r in range(rows + 1):
        lat = np.pi * r / rows - np.pi / 2
        for c in range(cols):
            lon = 2 * np.pi * c / cols
            verts.append([radius * np.cos(lat) * np.cos(lon),
                          radius * np.sin(lat),
                          radius * np.cos(lat) * np.sin(lon)])
    verts = np.array(verts, dtype=np.float32)
    for r in range(rows):
        for c in range(cols):
            a = r*cols+c; b = r*cols+(c+1)%cols
            d = (r+1)*cols+c; e = (r+1)*cols+(c+1)%cols
            faces += [[a,b,e],[a,e,d]]
    md = gl.MeshData(vertexes=verts, faces=np.array(faces, dtype=np.uint32))
    return gl.GLMeshItem(meshdata=md, smooth=True)


def _cylinder_mesh(start, end, radius, segs=12):
    axis = end - start; L = np.linalg.norm(axis)
    if L < 1e-6:
        return gl.GLMeshItem()
    z = axis / L
    ref = np.array([1,0,0]) if abs(z[0]) < 0.9 else np.array([0,1,0])
    x = np.cross(ref, z); x /= np.linalg.norm(x)
    y = np.cross(z, x)
    angles = np.linspace(0, 2*np.pi, segs, endpoint=False)
    rb = start + radius*(np.outer(np.cos(angles),x) + np.outer(np.sin(angles),y))
    rt = end   + radius*(np.outer(np.cos(angles),x) + np.outer(np.sin(angles),y))
    verts = np.vstack([rb, rt]).astype(np.float32)
    faces = []
    for i in range(segs):
        n = (i+1)%segs
        faces += [[i,n,segs+n],[i,segs+n,segs+i]]
    md = gl.MeshData(vertexes=verts, faces=np.array(faces, dtype=np.uint32))
    return gl.GLMeshItem(meshdata=md, smooth=False)


class RenderWidget(QWidget):
    def __init__(self, state, parent=None):
        super().__init__(parent)
        self._state      = state
        self._filters    = {n: QuaternionFilter() for n in ["chest","arm","wrist"]}
        self._prev_upper = np.array([0., -UPPER_ARM_LEN, 0.])
        self._prev_fore  = np.array([0., -FOREARM_LEN, 0.])
        self._rom_mode   = False
        self._rom_max    = {"flex": 0.0, "abd": 0.0, "rot": 0.0, "elbow": 0.0}
        self._build_ui()
        self._build_scene()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        hdr = QLabel("3D SKELETON")
        hdr.setStyleSheet(
            "color: #00b4ff; font-size: 11px; font-weight: bold; padding: 4px 8px; background: #0a0a0a;"
        )
        lay.addWidget(hdr)

        self._view = gl.GLViewWidget()
        self._view.setBackgroundColor(BG_COLOR)
        self._view.setCameraPosition(distance=1.2, elevation=15, azimuth=45)
        lay.addWidget(self._view, stretch=1)

        bar = QWidget()
        bar.setStyleSheet("background: #0a0a0a; border-top: 1px solid #232330;")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(8, 4, 8, 4)
        self._status_lbl = QLabel("Waiting for sensors...")
        self._status_lbl.setStyleSheet("color: #ffc800; font-size: 11px;")

        # ROM measure button
        self._rom_btn = QPushButton("Measure ROM")
        self._rom_btn.setFixedHeight(26)
        self._rom_btn.setStyleSheet(
            "QPushButton { background: #ffc80030; color: #ffc800; border: 1px solid #ffc80060;"
            " border-radius: 3px; font-size: 10px; padding: 2px 10px; }"
            "QPushButton:hover { background: #ffc80060; }"
        )
        self._rom_btn.clicked.connect(self._toggle_rom_mode)

        bl.addWidget(self._status_lbl, stretch=1)
        bl.addWidget(self._rom_btn)
        bar.setFixedHeight(36)
        lay.addWidget(bar)

    def _build_scene(self):
        grid = gl.GLGridItem()
        grid.setSize(2, 2); grid.setSpacing(0.1, 0.1)
        grid.setColor((50, 50, 60, 80))
        self._view.addItem(grid)

        torso = gl.GLBoxItem(size=QVector3D(0.08, 0.20, 0.12), color=C_TORSO)
        torso.translate(-0.04, -0.10, -0.06)
        self._view.addItem(torso)

        self._shoulder_pos = np.array([0.04 + 0.038, 0.10, 0.0])

        self._sph_shoulder = _sphere_mesh(0.038)
        self._sph_elbow    = _sphere_mesh(0.032)
        self._sph_wrist    = _sphere_mesh(0.026)
        for sph, col in [(self._sph_shoulder, C_SHOULDER),
                         (self._sph_elbow, C_ELBOW),
                         (self._sph_wrist, C_WRIST)]:
            sph.setColor(col)
            self._view.addItem(sph)

        self._sph_shoulder.translate(*self._shoulder_pos)
        elbow0 = self._shoulder_pos + np.array([0, -UPPER_ARM_LEN, 0])
        wrist0 = elbow0 + np.array([0, -FOREARM_LEN, 0])
        self._sph_elbow.translate(*elbow0)
        self._sph_wrist.translate(*wrist0)

        # Goal sphere (hidden until exercise selected)
        self._goal_sphere = _sphere_mesh(0.05)
        self._goal_sphere.setColor(C_GOAL)
        self._goal_sphere.setVisible(False)
        self._view.addItem(self._goal_sphere)
        self._goal_pos = None

        self._upper_mesh = self._forearm_mesh = None
        self._rebuild_bones(elbow0, wrist0)

    def _rebuild_bones(self, elbow, wrist):
        for attr in ["_upper_mesh", "_forearm_mesh"]:
            m = getattr(self, attr)
            if m is not None:
                self._view.removeItem(m)
        self._upper_mesh  = _cylinder_mesh(self._shoulder_pos, elbow, 0.025)
        self._forearm_mesh = _cylinder_mesh(elbow, wrist, 0.020)
        self._upper_mesh.setColor(C_UPPER_ARM)
        self._forearm_mesh.setColor(C_FOREARM)
        self._view.addItem(self._upper_mesh)
        self._view.addItem(self._forearm_mesh)

    def set_goal_position(self, pos_np: np.ndarray):
        """Place the goal sphere at a world-space position."""
        self._goal_pos = pos_np
        self._goal_sphere.resetTransform()
        self._goal_sphere.translate(*pos_np)
        self._goal_sphere.setVisible(True)

    def hide_goal(self):
        self._goal_sphere.setVisible(False)
        self._goal_pos = None

    def _toggle_rom_mode(self):
        if not self._rom_mode:
            self._rom_mode = True
            self._rom_max  = {"flex": 0.0, "abd": 0.0, "rot": 0.0, "elbow": 0.0}
            self._rom_btn.setText("Stop ROM Measure")
            self._rom_btn.setStyleSheet(
                "QPushButton { background: #ff3c3c30; color: #ff3c3c; border: 1px solid #ff3c3c60;"
                " border-radius: 3px; font-size: 10px; padding: 2px 10px; }"
            )
            print("[ROM] ROM measurement started.")
        else:
            self._rom_mode = False
            self._rom_btn.setText("Measure ROM")
            self._rom_btn.setStyleSheet(
                "QPushButton { background: #ffc80030; color: #ffc800; border: 1px solid #ffc80060;"
                " border-radius: 3px; font-size: 10px; padding: 2px 10px; }"
                "QPushButton:hover { background: #ffc80060; }"
            )
            print(f"[ROM] ROM result: {self._rom_max}")
            # Write measured ROM back to state as goal limits
            if self._state:
                with self._state.lock:
                    self._state.rom_flex_limit  = max(self._rom_max["flex"],  10.0)
                    self._state.rom_abd_limit   = max(self._rom_max["abd"],   10.0)
                    self._state.rom_rot_limit   = max(self._rom_max["rot"],   10.0)
                    self._state.rom_elbow_limit = max(self._rom_max["elbow"], 10.0)

    def refresh(self):
        IDENTITY = (1.,0.,0.,0.)
        if self._state is None:
            return

        with self._state.lock:
            calibrated = self._state.calibrated
            q_raw = {n: self._state.slots[n].get_quaternion()
                     for n in ["chest","arm","wrist"]}
            q_ref = ({n: self._state.calibration_quats.get(n, IDENTITY)
                      for n in ["chest","arm","wrist"]}
                     if calibrated else
                     {n: IDENTITY for n in ["chest","arm","wrist"]})
            flex  = self._state.shoulder_flexion
            abd   = self._state.shoulder_abduction
            rot   = self._state.external_rotation
            elbow = self._state.elbow_flexion

        # ROM tracking
        if self._rom_mode:
            self._rom_max["flex"]  = max(self._rom_max["flex"],  abs(flex))
            self._rom_max["abd"]   = max(self._rom_max["abd"],   abs(abd))
            self._rom_max["rot"]   = max(self._rom_max["rot"],   abs(rot))
            self._rom_max["elbow"] = max(self._rom_max["elbow"], abs(elbow))

        # Filter + mount → corrected rotations
        live = {n: self._filters[n].update(q_raw[n]) * MOUNT[n].inv()
                for n in ["chest","arm","wrist"]}
        ref  = {n: to_anatomical(q_ref[n], n) for n in ["chest","arm","wrist"]}
        corr = {n: ref[n].inv() * live[n] for n in ["chest","arm","wrist"]}

        shoulder_rot = corr["chest"].inv() * corr["arm"]
        elbow_rot    = corr["arm"].inv()   * corr["wrist"]

        upper_dir_np = shoulder_rot.apply(DOWN_NP) * UPPER_ARM_LEN
        fore_dir_np  = (shoulder_rot * elbow_rot).apply(DOWN_NP) * FOREARM_LEN

        upper_disp = WORLD_ROT.apply(upper_dir_np)
        fore_disp  = WORLD_ROT.apply(fore_dir_np)

        # Jump gate on display vectors
        def _safe(new, prev):
            if np.linalg.norm(new) < 1e-6:
                return prev
            nn = new / np.linalg.norm(new)
            pn = prev / (np.linalg.norm(prev) + 1e-9)
            if abs(np.dot(nn, pn)) < (1.0 - DIR_JUMP_THRESH):
                return prev
            return new

        upper_disp = _safe(upper_disp, self._prev_upper)
        fore_disp  = _safe(fore_disp,  self._prev_fore)
        self._prev_upper = upper_disp
        self._prev_fore  = fore_disp

        elbow_pos = self._shoulder_pos + upper_disp
        wrist_pos = elbow_pos + fore_disp

        self._sph_elbow.resetTransform(); self._sph_elbow.translate(*elbow_pos)
        self._sph_wrist.resetTransform(); self._sph_wrist.translate(*wrist_pos)
        self._rebuild_bones(elbow_pos, wrist_pos)

        n_conn = sum(1 for n in ["chest","arm","wrist"]
                     if self._state.slots[n].connected)
        if calibrated:
            self._status_lbl.setText("✓ Calibrated — tracking live")
            self._status_lbl.setStyleSheet("color: #00ffa0; font-size: 11px;")
        else:
            self._status_lbl.setText(f"Not calibrated  ({n_conn}/3 connected)")
            self._status_lbl.setStyleSheet("color: #ffc800; font-size: 11px;")
