"""
gui/panels/analytics_panel.py
------------------------------
Panel 3 — Analytics and progress tracking.

Tabs: Overview · ROM Trends · Session History · Pain & Function
"""

import sqlite3
from pathlib import Path
import pyqtgraph as pg
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QFrame, QTabWidget, QTableWidget, QTableWidgetItem,
    QAbstractItemView, QSizePolicy, QGridLayout
)
from PyQt5.QtCore import Qt

from ble.ble_state import AppState
from gui.styles import *

DB_PATH = Path(__file__).parent.parent.parent / "data" / "sessions.db"


def _load_sessions():
    if not DB_PATH.exists(): return []
    try:
        con = sqlite3.connect(DB_PATH)
        rows = con.execute(
            "SELECT id,date,exercise,duration_s,reps,"
            "max_flex,max_abd,max_ext_rot,max_elbow,pain_pre,pain_post "
            "FROM sessions ORDER BY id DESC"
        ).fetchall()
        con.close()
        return rows
    except Exception:
        return []


class BigMetric(QFrame):
    def __init__(self, label: str, colour: str, parent=None):
        super().__init__(parent)
        self.setStyleSheet(card_style(SURFACE2, BORDER))
        lay = QVBoxLayout(self); lay.setContentsMargins(12,10,12,10); lay.setSpacing(3)
        lbl = QLabel(label); lbl.setStyleSheet(label_style(GREEN3, 12))
        self._val = QLabel("—"); self._val.setStyleSheet(
            f"color:{colour};font-size:26px;font-weight:bold;font-family:'Courier New',monospace;"
        )
        self._delta = QLabel(""); self._delta.setStyleSheet(label_style(GREEN3, 11))
        lay.addWidget(lbl); lay.addWidget(self._val); lay.addWidget(self._delta)

    def set(self, val: str, delta: str = "", delta_pos: bool = True):
        self._val.setText(val)
        if delta:
            col = GREEN if delta_pos else RED
            self._delta.setText(delta)
            self._delta.setStyleSheet(label_style(col, 10))


class AnalyticsPanel(QWidget):
    def __init__(self, state: AppState, recorder, parent=None):
        super().__init__(parent)
        self._state    = state
        self._recorder = recorder
        self._build()

    def _build(self):
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)

        # Title bar
        tb = QWidget(); tb.setFixedHeight(36)
        tb.setStyleSheet(f"background:{SURFACE};border-bottom:1px solid {BORDER};")
        tl = QHBoxLayout(tb); tl.setContentsMargins(16,0,16,0)
        tl.addWidget(QLabel("ANALYTICS").also(lambda l: l.setStyleSheet(label_style(GREEN, 12, bold=True))))
        tl.addStretch()
        export_btn = QPushButton("EXPORT ALL")
        export_btn.setFixedHeight(26)
        export_btn.setStyleSheet(btn_style())
        tl.addWidget(export_btn)
        root.addWidget(tb)

        # Tabs
        tabs = QTabWidget()
        tabs.setStyleSheet(f"""
            QTabWidget::pane {{ border:none; background:{BG}; }}
            QTabWidget::tab-bar {{ left:0; }}
        """)
        tabs.addTab(self._build_overview(), "OVERVIEW")
        tabs.addTab(self._build_trends(),   "ROM TRENDS")
        tabs.addTab(self._build_history(),  "SESSION HISTORY")
        tabs.addTab(self._build_pain(),     "PAIN & FUNCTION")
        root.addWidget(tabs, stretch=1)

    def _build_overview(self):
        w = QWidget()
        lay = QVBoxLayout(w); lay.setContentsMargins(16,14,16,14); lay.setSpacing(12)

        lay.addWidget(QLabel("SESSION SUMMARY").also(lambda l: l.setStyleSheet(label_style(GREEN3, 12))))

        # Big metrics row
        mr = QHBoxLayout(); mr.setSpacing(10)
        self._m_flex  = BigMetric("MAX FLEXION",   C_FLEX)
        self._m_abd   = BigMetric("MAX ABDUCTION",  C_ABD)
        self._m_sym   = BigMetric("SYMMETRY",        CYAN)
        self._m_smooth= BigMetric("SMOOTHNESS",      C_ELBOW)
        for m in [self._m_flex, self._m_abd, self._m_sym, self._m_smooth]:
            mr.addWidget(m)
        lay.addLayout(mr)

        # ADL milestones
        lay.addWidget(QLabel("ADL MILESTONES").also(lambda l: l.setStyleSheet(label_style(GREEN3, 12))))
        adl_row = QHBoxLayout(); adl_row.setSpacing(10)
        self._adl = {}
        for name, key, thresh in [
            ("TOUCH HEAD", "max_flexion", 130),
            ("REACH OVERHEAD", "max_abduction", 150),
            ("PUT ON COAT", "max_ext_rot", 60),
        ]:
            f = QFrame(); f.setStyleSheet(card_style(SURFACE2, BORDER))
            fl = QVBoxLayout(f); fl.setContentsMargins(10,8,10,8); fl.setSpacing(4)
            nl = QLabel(name); nl.setStyleSheet(label_style(GREEN3, 11))
            tl2 = QLabel(f"≥{thresh}°"); tl2.setStyleSheet(label_style(TEXT3, 12))
            bar_bg = QFrame(); bar_bg.setFixedHeight(4)
            bar_bg.setStyleSheet(f"background:{SURFACE3};border-radius:2px;")
            bar_fill = QFrame(bar_bg); bar_fill.setFixedHeight(4)
            bar_fill.setStyleSheet(f"background:{AMBER};border-radius:2px;width:0px;")
            val_lbl = QLabel("—"); val_lbl.setStyleSheet(label_style(AMBER, 11, bold=True))
            fl.addWidget(nl); fl.addWidget(tl2); fl.addWidget(bar_bg); fl.addWidget(val_lbl)
            adl_row.addWidget(f)
            self._adl[name] = (bar_fill, val_lbl, thresh)
        lay.addLayout(adl_row)
        lay.addStretch()
        return w

    def _build_trends(self):
        w = QWidget()
        lay = QVBoxLayout(w); lay.setContentsMargins(16,14,16,14); lay.setSpacing(12)
        lay.addWidget(QLabel("ROM OVER SESSIONS").also(lambda l: l.setStyleSheet(label_style(GREEN3, 12))))

        self._trend_plot = pg.PlotWidget(background=SURFACE2)
        self._trend_plot.showGrid(x=True, y=True, alpha=0.15)
        self._trend_plot.getAxis("left").setTextPen(GREEN3)
        self._trend_plot.getAxis("bottom").setTextPen(GREEN3)
        self._trend_plot.getAxis("left").setPen(BORDER)
        self._trend_plot.getAxis("bottom").setPen(BORDER)
        self._trend_plot.setLabel("left", "Degrees", color=GREEN3)
        self._trend_plot.setLabel("bottom", "Session #", color=GREEN3)
        self._flex_trend  = self._trend_plot.plot(pen=pg.mkPen(C_FLEX,   width=2), name="Flexion")
        self._abd_trend   = self._trend_plot.plot(pen=pg.mkPen(C_ABD,    width=2), name="Abduction")
        self._rot_trend   = self._trend_plot.plot(pen=pg.mkPen(C_ROT,    width=2), name="Ext Rot")
        self._elbow_trend = self._trend_plot.plot(pen=pg.mkPen(C_ELBOW,  width=2), name="Elbow")
        self._trend_plot.addLegend()
        lay.addWidget(self._trend_plot, stretch=1)
        return w

    def _build_history(self):
        w = QWidget()
        lay = QVBoxLayout(w); lay.setContentsMargins(0,0,0,0)
        self._table = QTableWidget()
        self._table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._table.setAlternatingRowColors(True)
        self._table.setStyleSheet(
            f"QTableWidget{{background:{SURFACE2};alternate-background-color:{SURFACE3};"
            f"color:{TEXT2};border:none;gridline-color:{BORDER};}}"
            f"QTableWidget::item:selected{{background:{GREEN4};color:{GREEN};}}"
        )
        headers = ["#","DATE","EXERCISE","DUR","REPS","FLEX°","ABD°","SMOOTH","PAIN"]
        self._table.setColumnCount(len(headers))
        self._table.setHorizontalHeaderLabels(headers)
        lay.addWidget(self._table)
        return w

    def _build_pain(self):
        w = QWidget()
        lay = QVBoxLayout(w); lay.setContentsMargins(16,14,16,14); lay.setSpacing(12)
        lay.addWidget(QLabel("PAIN SCORE OVER SESSIONS").also(lambda l: l.setStyleSheet(label_style(GREEN3, 12))))
        self._pain_plot = pg.PlotWidget(background=SURFACE2)
        self._pain_plot.showGrid(x=True, y=True, alpha=0.15)
        self._pain_plot.setYRange(0, 10)
        self._pain_plot.getAxis("left").setTextPen(GREEN3)
        self._pain_plot.getAxis("bottom").setTextPen(GREEN3)
        self._pain_plot.getAxis("left").setPen(BORDER)
        self._pain_plot.getAxis("bottom").setPen(BORDER)
        self._pain_pre_curve  = self._pain_plot.plot(pen=pg.mkPen(AMBER, width=2), name="Pre")
        self._pain_post_curve = self._pain_plot.plot(pen=pg.mkPen(RED,   width=2), name="Post")
        self._pain_plot.addLegend()
        lay.addWidget(self._pain_plot, stretch=1)
        return w

    def refresh(self):
        sessions = _load_sessions()

        with self._state.lock:
            mf = self._state.max_flexion
            ma = self._state.max_abduction
            mr = self._state.max_ext_rot
            me = self._state.max_elbow

        # Overview metrics
        prev = sessions[1] if len(sessions) > 1 else None
        def _delta(cur, prev_val):
            if prev_val is None or prev_val == 0: return "", True
            d = cur - prev_val
            return f"{'↑' if d >= 0 else '↓'} {abs(d):.0f}° vs last", d >= 0

        self._m_flex.set(f"{mf:.0f}°", *_delta(mf, prev[5] if prev else None))
        self._m_abd.set(f"{ma:.0f}°",  *_delta(ma, prev[6] if prev else None))
        self._m_sym.set("—")
        self._m_smooth.set("—")

        # ADL
        for name, (bar_fill, val_lbl, thresh) in self._adl.items():
            val_map = {"TOUCH HEAD": mf, "REACH OVERHEAD": ma, "PUT ON COAT": mr}
            val = val_map.get(name, 0)
            pct = min(100, int(val / thresh * 100))
            done = val >= thresh
            col = GREEN if done else (AMBER if pct > 50 else RED)
            val_lbl.setText(f"{val:.0f}° / {thresh}°  {'✓' if done else ''}")
            val_lbl.setStyleSheet(label_style(col, 11, bold=True))

        if not sessions: return

        # Trend charts
        xs = list(range(1, len(sessions)+1))
        flexs  = [r[5] or 0 for r in reversed(sessions)]
        abds   = [r[6] or 0 for r in reversed(sessions)]
        rots   = [r[7] or 0 for r in reversed(sessions)]
        elbows = [r[8] or 0 for r in reversed(sessions)]
        self._flex_trend.setData(xs[:len(flexs)],   flexs)
        self._abd_trend.setData(xs[:len(abds)],    abds)
        self._rot_trend.setData(xs[:len(rots)],    rots)
        self._elbow_trend.setData(xs[:len(elbows)], elbows)

        # Pain chart
        pains_pre  = [r[9]  or 0 for r in reversed(sessions)]
        pains_post = [r[10] or 0 for r in reversed(sessions)]
        self._pain_pre_curve.setData(xs[:len(pains_pre)],   pains_pre)
        self._pain_post_curve.setData(xs[:len(pains_post)], pains_post)

        # History table
        self._table.setRowCount(len(sessions))
        for i, r in enumerate(sessions):
            vals = [
                str(r[0]),
                (r[1] or "")[:16],
                r[2] or "—",
                f"{r[3]:.0f}s" if r[3] else "—",
                str(r[4]) if r[4] is not None else "—",
                f"{r[5]:.0f}°" if r[5] else "—",
                f"{r[6]:.0f}°" if r[6] else "—",
                "—",
                f"{r[10]}/10" if r[10] is not None else "—",
            ]
            for j, v in enumerate(vals):
                item = QTableWidgetItem(v)
                item.setForeground(pg.mkColor(TEXT2))
                self._table.setItem(i, j, item)
        self._table.resizeColumnsToContents()

def _also(self, fn):
    fn(self); return self
QLabel.also = _also
