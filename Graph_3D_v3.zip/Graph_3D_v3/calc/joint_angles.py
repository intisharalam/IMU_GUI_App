"""
joint_angles.py  —  v3
----------------------
Computes shoulder and elbow joint angles from three IMU quaternions.
ISB convention: Wu et al., Journal of Biomechanics 38(5), 2005.

KEY DESIGN DECISIONS
────────────────────
1. SWING-TWIST decomposition for shoulder — numerically stable at all
   elevations including 0° (I-pose). Eliminates the YXY gimbal singularity
   that caused wild external-rotation swings near neutral.

2. SLERP quaternion low-pass filter (α=0.15 @ 50 Hz, ~7.5 Hz cutoff).
   Applied per-sensor in raw quaternion space before mounting correction.
   Kills high-frequency noise without adding meaningful lag for PT movements.

3. MEDIAN outlier gate — if any single-frame angle jump exceeds JUMP_THRESH_DEG,
   the output is held at the previous value for that frame. This handles the
   rare hard Euler discontinuity that slips through the filter.

4. Flexion/Abduction convention (verified against renderer):
     plane_elev ≈ 0°  → frontal plane  → ABDUCTION
     plane_elev ≈ 90° → sagittal plane → FLEXION

5. Elbow: ZXY decomposition, Z component = medial-lateral hinge.

SENSOR AXES (from placement photo, I-pose):
  IMU_CHEST     X→DOWN  Y→RIGHT  Z→BACK
  IMU_UPPER_ARM X→DOWN  Y→FWD    Z→RIGHT
  IMU_FOREARM   X→DOWN  Y→FWD    Z→RIGHT
Anatomical frame: X=FORWARD, Y=UP, Z=RIGHT
"""

import numpy as np
from scipy.spatial.transform import Rotation, Slerp

FILTER_ALPHA    = 0.15   # SLERP smoothing — raise for less lag, lower for less noise
JUMP_THRESH_DEG = 45.0   # max believable single-frame angle change


# ── Mounting helpers ──────────────────────────────────────────────────────────

def _mount(sx, sy, sz):
    mat = np.column_stack([sx, sy, sz]).astype(float)
    det = np.linalg.det(mat)
    assert abs(det - 1.0) < 1e-6, f"Mount matrix not right-handed (det={det:.6f})"
    return Rotation.from_matrix(mat)

FWD = np.array([1,0,0]); UP = np.array([0,1,0]); RIGHT = np.array([0,0,1])
DOWN = np.array([0,-1,0]); LEFT = np.array([0,0,-1]); BACK = np.array([-1,0,0])

MOUNT_CHEST = _mount(sx=DOWN, sy=RIGHT, sz=BACK)
MOUNT_ARM   = _mount(sx=DOWN, sy=FWD,   sz=RIGHT)
MOUNT_WRIST = _mount(sx=DOWN, sy=FWD,   sz=RIGHT)
MOUNT = {"chest": MOUNT_CHEST, "arm": MOUNT_ARM, "wrist": MOUNT_WRIST}


def _to_rot(q_wxyz):
    w, x, y, z = q_wxyz
    return Rotation.from_quat([x, y, z, w])

def to_anatomical(q_wxyz, sensor_name: str) -> Rotation:
    """Raw sensor quaternion → shared anatomical frame. MOUNT applied once."""
    return _to_rot(q_wxyz) * MOUNT[sensor_name].inv()


# ── Swing-twist decomposition ─────────────────────────────────────────────────

def swing_twist(rot: Rotation, twist_axis: np.ndarray):
    """
    Decompose rot = swing * twist where twist is a pure rotation about
    twist_axis. Numerically stable at all rotation magnitudes.
    Returns (swing: Rotation, twist_angle_deg: float, sign: +1/-1).
    """
    axis = twist_axis / np.linalg.norm(twist_axis)
    q    = rot.as_quat()          # (x,y,z,w) scipy convention
    vec  = q[:3]; w = q[3]
    proj = np.dot(vec, axis) * axis
    twist_q = np.array([proj[0], proj[1], proj[2], w])
    norm = np.linalg.norm(twist_q)
    if norm < 1e-10:
        return rot, 0.0
    twist_q /= norm
    twist = Rotation.from_quat(twist_q)
    swing = rot * twist.inv()
    proj_len  = np.linalg.norm(proj)
    angle_deg = np.degrees(2.0 * np.arctan2(proj_len, abs(w)))
    sign      = 1.0 if np.dot(proj, axis) >= 0 else -1.0
    if w < 0:
        sign = -sign
    return swing, sign * angle_deg


# ── QuaternionFilter ──────────────────────────────────────────────────────────

class QuaternionFilter:
    def __init__(self, alpha=FILTER_ALPHA):
        self._alpha   = alpha
        self._current = None

    def update(self, q_wxyz: tuple) -> Rotation:
        new = _to_rot(q_wxyz)
        if self._current is None:
            self._current = new
            return new
        slerp = Slerp([0.0, 1.0], Rotation.concatenate([self._current, new]))
        self._current = slerp(self._alpha)
        return self._current

    def reset(self):
        self._current = None


# ── JointAngles ───────────────────────────────────────────────────────────────

class JointAngles:
    """
    Computes filtered, outlier-gated ISB joint angles.
    Shoulder: swing-twist decomposition (stable at all elevations).
    Elbow:    ZXY Euler decomposition, Z component.
    """

    def __init__(self):
        self._ref_anat = {}
        self._filters  = {n: QuaternionFilter() for n in ["chest","arm","wrist"]}
        self._prev     = {
            "shoulder_flexion": 0.0, "shoulder_abduction": 0.0,
            "external_rotation": 0.0, "elbow_flexion": 0.0
        }

    def set_calibration(self, ref_quats: dict):
        for f in self._filters.values():
            f.reset()
        self._ref_anat = {name: to_anatomical(q, name) for name, q in ref_quats.items()}
        self._prev = {k: 0.0 for k in self._prev}
        print("[ANGLES] Calibration loaded. Filters reset.")

    def compute(self, live_quats: dict) -> dict:
        ZERO = dict(
            shoulder_flexion=0.0, shoulder_abduction=0.0,
            external_rotation=0.0, elbow_flexion=0.0,
            _plane_of_elevation=0.0, _elevation=0.0, _axial_rotation=0.0,
            _shoulder_rot=Rotation.identity(), _elbow_rot=Rotation.identity()
        )
        if not self._ref_anat:
            return ZERO

        # Step 1 — filter + mount
        live_anat = {}
        for name, q in live_quats.items():
            filtered = self._filters[name].update(q)
            live_anat[name] = filtered * MOUNT[name].inv()

        # Step 2 — remove I-pose offset
        corrected = {
            name: self._ref_anat[name].inv() * live_anat[name]
            for name in ["chest", "arm", "wrist"]
            if name in self._ref_anat and name in live_anat
        }
        if len(corrected) < 3:
            return ZERO

        # Step 3 — relative joint rotations (ISB)
        shoulder_rot = corrected["chest"].inv() * corrected["arm"]
        elbow_rot    = corrected["arm"].inv()   * corrected["wrist"]

        # Step 4 — shoulder: swing-twist about humerus long axis
        swing, axial_rot = swing_twist(shoulder_rot, DOWN)
        swing_euler = swing.as_euler("ZXY", degrees=True)
        plane_elev  = float(swing_euler[0])
        elevation   = float(swing_euler[1])

        # plane_elev≈0 → frontal → abduction; plane_elev≈90 → sagittal → flexion
        in_frontal = abs(plane_elev) < 45 or abs(plane_elev) > 135
        flexion    = elevation if not in_frontal else 0.0
        abduction  = elevation if in_frontal     else 0.0

        # Step 5 — elbow ZXY, Z = hinge
        elbow_flex = float(elbow_rot.as_euler("ZXY", degrees=True)[0])

        # Step 6 — outlier gate: hold previous value on large jump
        result = {
            "shoulder_flexion":    flexion,
            "shoulder_abduction":  abduction,
            "external_rotation":   axial_rot,
            "elbow_flexion":       elbow_flex,
            "_plane_of_elevation": plane_elev,
            "_elevation":          elevation,
            "_axial_rotation":     axial_rot,
            "_shoulder_rot":       shoulder_rot,
            "_elbow_rot":          elbow_rot,
        }
        for key in ["shoulder_flexion","shoulder_abduction","external_rotation","elbow_flexion"]:
            if abs(result[key] - self._prev[key]) > JUMP_THRESH_DEG:
                result[key] = self._prev[key]
            else:
                self._prev[key] = result[key]

        return result


# ── AngleProcessor ────────────────────────────────────────────────────────────

class AngleProcessor:
    """Called every frame. Detects recalibration by dict identity."""

    def __init__(self, state, calibration):
        self._state       = state
        self._calibration = calibration
        self._angles      = JointAngles()
        self._last_cal_id = None

    def update(self, timestamp: float):
        with self._state.lock:
            calibrated = self._state.calibrated
            cal_id     = id(self._state.calibration_quats)
            cal_quats  = dict(self._state.calibration_quats) if calibrated else {}

        if calibrated and cal_id != self._last_cal_id:
            self._angles.set_calibration(cal_quats)
            self._last_cal_id = cal_id

        if not calibrated or self._last_cal_id is None:
            return

        with self._state.lock:
            live_quats = {n: self._state.slots[n].get_quaternion()
                          for n in ["wrist", "arm", "chest"]}

        result = self._angles.compute(live_quats)

        with self._state.lock:
            self._state.update_joint_angles(
                flexion   = result["shoulder_flexion"],
                abduction = result["shoulder_abduction"],
                ext_rot   = result["external_rotation"],
                elbow     = result["elbow_flexion"],
                timestamp = timestamp,
            )
